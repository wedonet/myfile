﻿外国语大学




目录结构

docker-compose.yum  : docker配置文件

mysql : mysql数据库
nginx :
	
php:

web：laravel应用代码
	

使用方法：

当前目录下执行

$ docker-compose up -d